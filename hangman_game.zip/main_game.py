import random
import os
import csv

# ========================================================================================================== #
#                                          CONSTANTS: ANSI COLOURS
# ==========================================================================================================
"""ansi_constants"""
ANSI_RED = "\033[91m"
ANSI_GREEN = "\033[92m"
ANSI_YELLOW = "\033[93m"
ANSI_RESET = "\033[0m"



# ========================================================================================================== #
#                                          FILE HANDLING FUNCTIONS
# ========================================================================================================== #

## CSV feature ##
def load_csv(file_name='hangman_words.csv'):
    """Loads words and hints from a CSV file."""
    word_list = []
    if os.path.exists(file_name):
        with open(file_name, mode='r', newline='') as file:
            csv_reader = csv.reader(file)
            for csv_row in csv_reader:
                if len(csv_row) == 2:
                    word_list.append((csv_row[0].lower(), csv_row[1]))
    return word_list

##  custom words feature ##
def add_custom(file_name='hangman_words.csv'):
    """user inputs a word of their choice with a hint into the csv"""
    hangman_word = input("\nEnter a word to add and press enter: ").lower()
    word_hint = input("Enter a hint for the word and press enter: ")
    with open(file_name, mode='a', newline='') as file:
        csv_writer = csv.writer(file)
        csv_writer.writerow([hangman_word, word_hint])
    print(f"\n{ANSI_GREEN}Custom word added successfully{ANSI_RESET}\n")
    input("Press enter to return to the main menu... ")



# ========================================================================================================== #
#                                         GAME UTILITY FUNCTIONS
# ========================================================================================================== #

## rule outline ##
def view_rules():
    """Creator greets the user and displays rules"""
    ### variable for rule ascii title ###
    ascii_rules = rf"""
{ANSI_YELLOW}============================================================
 _   _ _____  _    _   _____ _____  ______ _       _____   __
| | | |  _  || |  | | |_   _|  _  | | ___ \ |     / _ \ \ / /
| |_| | | | || |  | |   | | | | | | | |_/ / |    / /_\ \ V /
|  _  | | | || |/\| |   | | | | | | |  __/| |    |  _  |\ /
| | | \ \_/ /\  /\  /   | | \ \_/ / | |   | |____| | | || |
\_| |_/\___/  \/  \/    \_/  \___/  \_|   \_____/\_| |_/\_/  
============================================================{ANSI_RESET}
"""
    print(ascii_rules)
    print(f"{ANSI_YELLOW}Hi! I am the creator of this game. Here is how you play Hangman!{ANSI_RESET}\n")
    
    print("\n1. Choose a Difficulty: You will be given three difficulty options based on the length of the word")
    print("  - Easy: 4-5 letters")
    print("  - Medium: 6-7 letters")
    print("  - Hard: 8 or more letters")
    
    print("2. Guess the Word")
    print(" - You will start with 100 points. The goal is to guess the word before your score reaches 0.")
    print(" - You can either guess a single letter or the whole word at once.")
    
    print("3. Earn Points")
    print(" - You earn 10 points for each correct guess (whether it's a letter or a full word).")
    
    print("4. Lose Points for Incorrect Guesses")
    print(" - For each incorrect guess, you lose 10 points.")
    
    print("5. Hint System")
    print(" - When your score drops to 30 or higher, you’ll get a hint for the word.")

    print("6. The Hangman Drawing")
    print(" - Each time you make an incorrect guess, a part of the hangman figure is drawn.")
    print(" - If the drawing is completed, it will give you a warning.\n")
    
    print(f"{ANSI_GREEN}7. Winning the Game{ANSI_RESET}")
    print(" - You win the game if you correctly guess the word before your score reaches 0.\n")
    
    print(f"{ANSI_RED}8. Game Over{ANSI_RESET}")
    print(" - If your score reaches 0 or the hangman is fully drawn, the game ends.")

    input("\nPress enter to return to the main menu... ")


## difficulty (easy, medium, hard) feature ##
def difficulty_level(hangman_word):
    """catagorises all words in csv to easy, medium and hard difficulties using letter ranges"""
    if len(hangman_word) <= 5:
        return 'Easy'
    elif len(hangman_word) <= 7:
        return 'Medium'
    else:
        return 'Hard'

## selecting difficulty setting ##
def choose_difficulty():
    """gives player choice to select a difficulty setting to play game"""
    while True:
        print("\nChoose a Difficulty:")
        print(f"{ANSI_GREEN}1. Easy (4-5 letters){ANSI_RESET}")
        print(f"{ANSI_YELLOW}2. Medium (6-7 letters){ANSI_RESET}")
        print(f"{ANSI_RED}3. Hard (8+ letters){ANSI_RESET}")
        difficulty_choice = input("Enter difficulty level (1/2/3) and press enter: ")
        if difficulty_choice == '1':
            return 'Easy'
        elif difficulty_choice == '2':
            return 'Medium'
        elif difficulty_choice == '3':
            return 'Hard'
        else:
            print("Invalid choice. Please enter 1, 2, or 3.")



# ========================================================================================================== #
#                                              MAIN GAME LOGIC
# ========================================================================================================== #

## componenets of hangman gameplay (features: score system, letter/word choice, hint, game progress display) ##
def main_game():
    """Runs the Hangman game, where players guess a word by letters or whole guesses, with scoring, hints, and ASCII visuals until they win or lose."""
    ### feature that tells user to add words (word,hint) into csv if csv is empty ###
    word_list = load_csv()
    if not word_list:
        print("No words available. Please add words using the custom words feature.")
        return
    
    ### catagorises word based on difficulty ###
    chosen_difficulty = choose_difficulty()
    catagorised_words = [(word, hint) for word, hint in word_list if difficulty_level(word) == chosen_difficulty]
    
    if not catagorised_words:
        print(f"No words available for {chosen_difficulty} difficulty. Please add more words.")
        return
    
    current_score = 100
    incorrect_guesses = 0
    guessed_letters = []
    word, hint = random.choice(catagorised_words)
    displayed_word = ['_'] * len(word)
    hint_shown = False

    ### intro to gameplay ###
    print("\nWelcome to Hangman!")
    print(f"Difficulty Level: {chosen_difficulty}\n")
    print(f"Score: {current_score}\n")
    print(f"Word to guess: {' '.join(displayed_word)}\n")

    ### hangman ascii drawing game progress display feature ###
    ascii_hangman = [
        """
        +---+
            |
            |
            |
            |
            |
        ===""", 
        """
        +---+
        O   |
            |
            |
            |
            |
        ===""", 
        """
        +---+
        O   |
        |   |
            |
            |
            |
        ===""", 
        """
        +---+
        O   |
       /|   |
            |
            |
            |
        ===""", 
        """
        +---+
        O   |
       /|\\  |
            |
            |
            |
        ===""", 
        """
        +---+
        O   |
       /|\\  |
       /    |
            |
            |
        ===""", 
        """
        +---+
        O   |
       /|\\  |
       / \\  |
            |
            |
        ==="""
    ]
    
    ### check guess ###
    while current_score > 0:
        print(f"\nCurrent Word: {' '.join(displayed_word)}")
        player_guess = input("Enter a letter or whole word: ").lower()
        #### single letter guess ####
        if len(player_guess) == 1:
            if player_guess in guessed_letters:
                print("You've already guessed that letter.")
                continue
            guessed_letters.append(player_guess)
            if player_guess in word:
                print(f"Good guess! The letter '{player_guess}' is in the word.")
                for i, letter in enumerate(word):
                    if letter == player_guess:
                        displayed_word[i] = player_guess
                current_score += 10
            else:
                print(f"Sorry, the letter '{player_guess}' is not in the word.")
                incorrect_guesses += 1
                current_score -= 10
        #### whole word guess ####
        elif len(player_guess) == len(word):
            if player_guess == word:
                print(f"{ANSI_GREEN}Congratulations! You guessed the word '{word}' correctly with only {incorrect_guesses} incorrect guesses!{ANSI_RESET}")  
                current_score += 10
                print(f"{ANSI_GREEN}Your final score is {current_score}!{ANSI_RESET}")
                break
            else:
                print(f"Sorry, '{player_guess}' is not the correct word.")
                incorrect_guesses += 1
                current_score -= 10
        else:
            print("Invalid input. Please enter a single letter or full word.")
        
        ### hint feature ###
        if current_score == 30 and not hint_shown:
            print(f"{ANSI_GREEN}It seems like you need some help...")
            print(f"Hint: {hint}{ANSI_RESET}")
            hint_shown = True
        
        print(f"Score: {current_score}\n")
        
        ### display hangman drawing game progress display feature ###
        if incorrect_guesses > 0:
            if incorrect_guesses < len(ascii_hangman):
                print(ascii_hangman[incorrect_guesses - 1])
            else:
                print(f"{ANSI_RED}{ascii_hangman[-1]}{ANSI_RESET}")
                print(f"{ANSI_RED}Hangman fully drawn!{ANSI_RESET}")
                print(f"{ANSI_YELLOW}WARNING: YOU HAVE UNTIL SCORE REACHES 0 TO SAVE HANGMAN{ANSI_RESET}")
        
        ### winner ###
        if '_' not in displayed_word:
            print(f"{ANSI_GREEN}Congratulations YOU SAVED HANGMAN! You've guessed the word '{word}' with {incorrect_guesses} incorrect guesses!{ANSI_RESET}")
            print(f"{ANSI_GREEN}Final Score: {current_score}!{ANSI_RESET}")
            break
    
    ### loser ###
    if current_score <= 0:
        print(f"{ANSI_RED}Game over! The word was '{word}'. Final score: {current_score}, Incorrect guesses: {incorrect_guesses}{ANSI_RESET}")
    input("Press enter to go back to the main menu...")

## variables for ascii greeting and exiting titles ##
welcome_message = rf"""
 _    _      _                            _         
| |  | |    | |                          | |        
| |  | | ___| | ___ ___  _ __ ___   ___  | |_ ___   
| |/\| |/ _ \ |/ __/ _ \| '_  _ \ / _  \ | __/ _ \  
\  /\  /  __/ | (_| (_) | | | | | |  __/ | || (_) | 
 \/  \/ \___|_|\___\___/|_| |_| |_|\___|  \__\___/  
{ANSI_YELLOW}                                                 
===================================================                                                
 _   _   ___   _   _ _____ ___  ___  ___   _   _    
| | | | / _ \ | \ | |  __ \|  \/  | / _ \ | \ | |   
| |_| |/ /_\ \|  \| | |  \/| .  . |/ /_\ \|  \| |   
|  _  ||  _  || .   | | __ | |\/| ||  _  || .   |   
| | | || | | || |\  | |_\ \| |  | || | | || |\  |   
\_| |_/\_| |_/\_| \_/\____/\_|  |_/\_| |_/\_| \_/    
===================================================
{ANSI_RED}
  +---+
  |   |
  O   |
 /|\  |
 / \  |
      |
   ===
| HELP ME!|{ANSI_RESET}                                                                                                                      
"""
exiting_message = rf"""
{ANSI_YELLOW}          _____ _   _   ___   _   _  _   __ _____          
 ______  |_   _| | | | / _ \ | \ | || | / //  ___|  ______ 
|______|   | | | |_| |/ /_\ \|  \| || |/ / \ `--.  |______|
 ______    | | |  _  ||  _  || . ` ||    \  `--. \  ______ 
|______|   | | | | | || | | || |\  || |\  \/\__/ / |______|
           \_/ \_| |_/\_| |_/\_| \_/\_| \_/\____/          
                                                           
                                                           
  __            ______ _       _____   _______ _   _ _____ 
 / _|           | ___ \ |     / _ \ \ / /_   _| \ | |  __ \
| |_ ___  _ __  | |_/ / |    / /_\ \ V /  | | |  \| | |  \/
|  _/ _ \| '__| |  __/| |    |  _  |\ /   | | | . ` | | __ 
| || (_) | |    | |   | |____| | | || |  _| |_| |\  | |_\ \
|_| \___/|_|    \_|   \_____/\_| |_/\_/  \___/\_| \_/\____/                                                                                                      
"""
menu_message = rf"""
{ANSI_YELLOW}

=========================================================================
         ___  ___  ___  _____ _   _  ___  ___ _____ _   _ _   _          
 ______  |  \/  | / _ \|_   _| \ | | |  \/  ||  ___| \ | | | | |  ______ 
|______| | .  . |/ /_\ \ | | |  \| | | .  . || |__ |  \| | | | | |______|
 ______  | |\/| ||  _  | | | | . ` | | |\/| ||  __|| . ` | | | |  ______ 
|______| | |  | || | | |_| |_| |\  | | |  | || |___| |\  | |_| | |______|
         \_|  |_/\_| |_/\___/\_| \_/ \_|  |_/\____/\_| \_/\___/          
=========================================================================
{ANSI_RESET}            



                --------------------------------------------
               | choose an option to navigate game (1/2/3/4) | 
                --------------------------------------------


"""

## main menu game navigation ##
def main_menu():
    """displays main menu screen for player to navigate the game and runs main game loop"""
    print(welcome_message)
    input("Press enter to go to main menu: ")
    while True:
        print(menu_message)
        print("1. Play Game")
        print("2. Add Custom Word")
        print("3. View Rules")
        print("4. Exit")
        menu_choice = input("Choose an option (1/2/3/4) and press enter: ")

        if menu_choice == '1':
            main_game()
        elif menu_choice == '2':
            add_custom()
        elif menu_choice == '3':
            view_rules()
        elif menu_choice == '4':
            print(exiting_message)
            break
        else:
            print("Invalid choice, please try again.")

## runs main menu when script executed ##
if __name__ == "__main__":
    main_menu()